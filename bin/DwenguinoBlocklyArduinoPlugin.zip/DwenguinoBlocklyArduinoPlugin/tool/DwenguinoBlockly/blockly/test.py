startdates = [datetime.date(2016, 9, 26), ]
